var max = 10

for (var i = 0; i < max; i++) {
    console.log(i)    
}